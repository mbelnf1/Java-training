/**
 * 
 */
/**
 * @author mosta
 *
 */
module NameConsole {
}