package yourworkhere;


	
public abstract class CheckingAccount extends Account{
	
	
	public static final Object String = null;
	public double overdraftFee;
	
	public abstract void getAccountManager();
	public CheckingAccount(String accountID, double balance,String AccountType, String firstName, String lastName, double overdraftFee){
		 super(accountID, firstName, lastName);
	        this.overdraftFee = overdraftFee;
	} 
	public String toString() {
		return "Account ID: " + getAccountID()+ ", Name: " + getFirstName() + " " + getLastName() +", Minimum Balance: " + getminBalance() + ", Account Type: " + getAccountType()+ "Overdraft Fees: " + getOverdraftFee();
	}
	private double getOverdraftFee() {
		// TODO Auto-generated method stub
		return overdraftFee;
	}
	private String minBalance;
	private String getminBalance() {
		return this.getminBalance();
	}
		// TODO Auto-generated method stub
		
	}
