package yourworkhere;
import yourworkhere.CheckingAccount;
public abstract class CheckingAccountManager implements IAccountManager {
	
	private CheckingAccount acct;
    public CheckingAccountManager(CheckingAccount acct) {
        this.acct = acct;
    } 

@Override
public boolean deposit(double amount) {
    if (amount > 0) {
        acct.setbalance( acct.getbalance() + amount );
        return true;
    } else
        return false;
}
	
	double balance;
	double getbalance() {
		return balance;
		
	}
	public void setbalance(double value) {
		double balance = value;
	}
}
	
	
