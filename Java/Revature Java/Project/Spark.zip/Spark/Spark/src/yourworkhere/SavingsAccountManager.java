package yourworkhere;

public class SavingsAccountManager implements IAccountManager {
	double balance;
	double getbalance;
	public void setbalance(double value) {
		balance = value;
	}
	private SavingsAccount acct;
    public SavingsAccountManager(SavingsAccount acct) {
        this.acct = acct;
    } 

	@Override
	
	public boolean deposit(double amount) {
	    if (amount > 0) {
	        acct.setbalance( acct.getbalance() + amount );
	        return true;
	    } else
	        return false;
	}
	public boolean withdraw(double amount) {
		     if (amount > 0) {
		     	acct.setbalance= (acct.getbalance() - amount- acct.getOverdraftFee());
		     	return false;
	}else {
			acct.setbalance = acct.getbalance() - amount;
			return true;

		}
	}
}
		     					
	
		  
