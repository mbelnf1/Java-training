package yourworkhere;

public interface IAccountManager {
	
	public boolean deposit(double balance);		
	public boolean withdraw(double balance);
}
	
	

	
	
	
