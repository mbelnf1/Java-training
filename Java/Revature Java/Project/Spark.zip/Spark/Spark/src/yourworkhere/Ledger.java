package yourworkhere;

public class Ledger {
	//the single instance of Ledger
	private static final Ledger instance = new Ledger();
	private static Ledger nextaccountID;
	private static void accounts(String value) {
	} 
	
	//private constructor    
	private Ledger() {}
	private void accounts() {}
	
	

	//method to return the single instance
	public static Ledger getInstance(){
	    return instance;
	}
	public static <getAllAccounts> Object main(String[] args) {
		 getAllAccounts Accounts = getAllAccounts();
			return Accounts;
	}
	private static <getAllAccounts> getAllAccounts getAllAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	public static Ledger getNextAccountID() {
			return nextaccountID;
	}
	public Ledger createAccount() {
		return null;
	} 
		
	public static String Ledger (String[] args) {
		String Account= retreive();
			return Account;
	}

	private static String retreive() {
		// TODO Auto-generated method stub
		return null;
	}
}
