package yourworkhere;

public class OverdraftException extends RuntimeException {

}
