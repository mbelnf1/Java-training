package yourworkhere;
public class SavingsAccount extends Account {
    private double minBalance;
    private int currentMonthlyWithdrawals;
    private int maxMonthlyWithdrawals;
	private double OverdraftFee;
	double setbalance;
    
    //The new stuff for this project starts here.
    
    
    public SavingsAccount(String accountID, String firstName, String lastName, double minBalance, int currentMonthlyWithdrawals, int maxMonthlyWithdrawals) {
        super(accountID, firstName, lastName);
        this.minBalance = minBalance;
        this.currentMonthlyWithdrawals = currentMonthlyWithdrawals;
        this.maxMonthlyWithdrawals = maxMonthlyWithdrawals;
    }
    double getOverdraftFee() {
		// TODO Auto-generated method stub
		return OverdraftFee;
	}
    @Override
    public String toString() {
	   return "Account ID: " + getAccountID()+ ", Name: " + getFirstName() + " " + getLastName() +", Minimum Balance: " + getminBalance() +", Current Monthly Withdrawals: " + getcurrentMonthlyWithdrawals() +", Maximum Monthly Withdrawals: " + getmaxMonthlyWithdrawals();
   }
	private String getmaxMonthlyWithdrawals() {
		// TODO Auto-generated method stub
		return null;
	}
	private String getcurrentMonthlyWithdrawals() {
		// TODO Auto-generated method stub
		return null;
	}
	private String getminBalance() {
		// TODO Auto-generated method stub
		return null;
	}
   
}
